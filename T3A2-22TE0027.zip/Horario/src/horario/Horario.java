package horario;

import java.util.Scanner;

public class Horario {

    public static void main(String[] args) {
        horas();
    }

    public static void horas() {
        int resultado1;
        int resultado;
        int resultado2;

        Scanner sc = new Scanner(System.in);
        Horario1 p = new Horario1();
        System.out.println("1.LUNES"
                + "\n2.MARTES"
                + "\n3.MIERCOLES"
                + "\n4.JUEVES"
                + "\n5.VIERNES"
                + "\n6.SABADO"
                + "\n7.DOMINGO");

        System.out.println("QUE DIA ENTRASTE?(escribe el numero):");
        int horario = sc.nextInt();
        p.setHorario(horario);

        System.out.println("HORA EN LA QUE ENTRASTE:");
        int reloj1 = sc.nextInt();
        p.setReloj1(reloj1);

        System.out.println("QUE DIA SALISTE?(escribe el numero):");
        int horario1 = sc.nextInt();
        p.setHorario1(horario1);

        System.out.println("HORA EN QUE SALISTE");
        int reloj2 = sc.nextInt();
        p.setReloj2(reloj2);

        if (horario > 7 && horario1 > 7) {
            System.out.println("INGRESA TU VALOR CORRECTAMENTE");
        } else {
            if (horario == 1 && horario1 == 1) {
                System.out.println("AUN NO");
            }
            if (horario == 1 && horario1 == 2) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());

            }
            if (horario == 1 && horario1 == 3) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + 24 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());

            }
            if (horario == 1 && horario1 == 4) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + 24 + 24 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());

            }
            if (horario == 1 && horario1 == 5) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + 24 + 24 + 24 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());

            }
            if (horario == 1 && horario1 == 6) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + 24 + 24 + 24 + 24 + 24 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());

            }
            if (horario == 1 && horario1 == 7) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + 24 + 24 + 24 + 24 + 24 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());

            }

            if (horario == 2 && horario <= 2) {
                System.out.println("AUN NO");
            }

            if (horario == 2 && horario1 == 3) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());
            }
            if (horario == 2 && horario1 == 4) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + 24 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());
            }
            if (horario == 2 && horario1 == 5) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + 24 + 24 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());
            }
            if (horario == 2 && horario1 == 6) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + 24 + 24 + 24 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());
            }
            if (horario == 2 && horario1 == 7) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + 24 + 24 + 24 + 24 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());
            }
            if (horario == 3 && horario1 <= 3) {
                System.out.println("AUN NO");
            }
            if (horario == 3 && horario1 == 4) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());
            }
            if (horario == 3 && horario1 == 5) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + 24 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());
            }
            if (horario == 3 && horario1 == 6) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + 24 + 24 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());
            }
            if (horario == 3 && horario1 == 7) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + 24 + 24 + 24 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());
            }
            if (horario == 4 && horario1 <= 4) {
                System.out.println("RESULTADO ES");
            }
            if (horario == 4 && horario1 == 5) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());
            }
            if (horario == 4 && horario1 == 6) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + resultado2;
                p.setResultado(resultado);
                System.out.println("el resultado es" + p.toString());
            }
            if (horario == 4 && horario1 == 7) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());
            }
            if (horario == 5 && horario1 <= 5) {
                System.out.println("RESULTADO ES");
            }
            if (horario == 5 && horario1 == 6) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());
            }
            if (horario == 5 && horario1 == 7) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + 24 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());
            }
            if (horario == 6 && horario1 <= 6) {
                System.out.println("RESULTADO ES");
            }
            if (horario == 6 && horario1 == 7) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + resultado2;
                p.setResultado(resultado);
                System.out.println("RESULTADO ES" + p.toString());
            }
            if (horario == 7 && horario1 <= 7) {
                resultado1 = 24 - reloj1;
                resultado2 = 24 - reloj2;
                resultado = resultado1 + 24 + resultado2;
                p.setResultado(resultado);
                System.out.println("INGRESA BIEN LOS DIAS");
            }

        }
    }
}
